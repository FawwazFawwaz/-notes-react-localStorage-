import '../styles/style.css';
import Input from './body/Input'
import List from './body/List'
import Archive from './body/Archive';
import { getInitialData } from '../utils';
import React, { useState, useEffect } from "react";


const Note = () =>{
  const data = localStorage.getItem('notes') ? JSON.parse(localStorage.getItem('notes')) : getInitialData();
const [notes, setNotes] = useState(data);

  
  // Mengambil data dari local storage saat aplikasi di-load
  useEffect(() => {
    const savedNotes = JSON.parse(localStorage.getItem("notes"));
    if (savedNotes) {
      setNotes(savedNotes);
    }
  }, []);
  
  // Menyimpan data ke dalam local storage setiap kali nilai dari state notes berubah
  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);
  
  const addNote = (note) => {
    setNotes([...notes, note]);
  };
  
  const handleDelete = (id) => {
    const updatedNotes = notes.filter((note) => note.id !== id);
    setNotes(updatedNotes);
  };
  
  const handleArchive = (id) => {
    const newNotes = notes.map((note) => {
      if (note.id === id) {
        return { ...note, archived: true };
      } else {
        return note;
      }
    });
    setNotes(newNotes);
  };
  
  const handleUnarchive = (id) => {
    const newNotes = notes.map((note) => {
      if (note.id === id) {
        return { ...note, archived: false };
      } else {
        return note;
      }
    });
    setNotes(newNotes);
  };
  
  const archivedNotes = notes.filter((note) => note.archived);
  const activeNotes = notes.filter((note) => !note.archived);
  
  const [searchTerm, setSearchTerm] = useState("");
  const filteredData = notes.filter((note) => {
    return note.title.toLowerCase().includes(searchTerm.toLowerCase());
  });
  
    return(
      <>
      <div className="note-app__header">
            <h1>Notes</h1>
            <div className="note-search">
            <input type="text" placeholder="Cari catatan ..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}/>
            </div>
      </div>
      <div className="note-app__body">
        <Input addNote={addNote}/>
        <List activeNotes={activeNotes} onDelete={handleDelete} handleArchive={handleArchive} filteredData={filteredData} searchTerm={searchTerm} notes={notes}/>
        <Archive handleUnarchive={handleUnarchive} archivedNotes={archivedNotes} onDelete={handleDelete}/>
    </div>
    </>
    )
}

export default Note;