import '../../styles/style.css';
import React, { useState} from 'react'



const Input = (props) => {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [lastId, setLastId] = useState(6);

  const handleAddNote = (event) => {
    event.preventDefault();
    const date = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const createdAt = date.toLocaleDateString('id-ID', options);
    const note = { title, body, createdAt, id: lastId + 1, archived: false };
    props.addNote(note);
    setTitle("");
    setBody("");
    setLastId(lastId + 1)
  };

  const maxLength = 50;
  const remainingChars = maxLength - title.length;

    return(
    <>
    <div className="note-input">
        <h2>Buat catatan</h2>
        <form>
            <p className="note-input__title__char-limit">Sisa karakter: {remainingChars}</p>
            <input className="note-input__title" type="text" placeholder="Ini adalah judul ..." value={title} onChange={(e) => setTitle(e.target.value)} maxLength={maxLength}/>
            <textarea className="note-input__body" type="text" placeholder="Tuliskan catatanmu di sini ..." value={body} onChange={(e) => setBody(e.target.value)}></textarea>
            <button type="submit" onClick={handleAddNote}>Buat</button>
        </form>
    </div>
    </>
    );
};

export default Input;